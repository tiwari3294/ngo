
<html>
<head>
<title>NGO website</title>
<link type ="text/css" rel="stylesheet" href="mystyle.css">
</head>
<body>


<div id="header" class="layout">

<center><h1>Children Care</h1></center>
  	
</div>
<div id="menu" class="layout">
		<ul>
<li><a href="home.php" alt="desciption">Home</a></li>
	<li><a href="donation.php" alt="desciption"> Donation</a></li>
	<li><a href="edu.php" alt="desciption">Providing education</a></li>
	<li><a href="enroll.php" alt="desciption">Enrolling in NGO</a></li>
                
<li><a href="contact us.php" alt="desciption">Contact us</a></li>

	</ul>
</div>

<div id="nav" class="layout">

 <div id="lc" class="cols">
	 
Contact Points at Save the Children IndiaFor making a donation and donation related queries prior to making a donation, please call 0124-4872100<br>
If you are looking for a partner for your CSR initiatives & Corporate Tie-ups,
 please contact:Richa Agrawal: +91 124 4752000Email ID:  r.agr@savethechildren.
 <br>inExisting DonorsFor suggestions and complaints, please contact:  Richa Agrawal Ph: +91124 4752000 (Extension - 2170)(Monday to Friday, 9:30 am to 5:30 pm)
 E-Mail: r.agr@savethechildren.in
<br>For 80G Certificates, Cancellation requestsand queries, please contact:  Richa Agrawal / Manisha Dimri Ph: +91 981 132 0906Ph:
 +91 124 4752000 (Extension - 2124 / 2125) (Monday to Friday, 9:30 am to 5:30 pm)E-Mail: donorsupport@savethechildren.
InFor Trusts and High value donations,<br> please contact:Richa Agrawal Phone: +91 124 4752000 Email: c.sethi@savethechildren.

 
    </div>
	

 
	
   

         
   
 <div id="rc" class="cols">
 
        <h4>The donor gets 50% tax rebate from its tax whie donating to an NGO which has 80g registration.</h4>
        <h4>The donor gets 100% tax rebate from its tax whie donating to an NGO which ha 35ac registration.</h4>
		<p>MAKE A DONATION Choose Your Donation Billing Information Type of donation Monthly donation One-time donation 
 Amount (INR)2,500a month can bring continuous education for 3 children1,500a month can bring continuous education and nutrition to a child1,
 000a month can bring continuous education help to 1 child500a month can bring nutrition help to an infantOther (the more you can do, the more 
 it can help children of our country) 
                 ss</p>
         


 
</div>
 </div>  
<div id="footer" class="layout">
<a href="contact us.php" alt="description"><h1>Contact us </h1></a>
</div>

</div>
</body> 
</html>
