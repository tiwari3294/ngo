
<html>
<head>
<title>NGO website</title>
<link type ="text/css" rel="stylesheet" href="mystyle.css">
</head>
<body>


<div id="header" class="layout">

<center><h1> Children Care</h1></center>
  	
</div>
<div id="menu" class="layout">
		<ul>
<li><a href="home.php" alt="desciption">Home</a></li>
	<li><a href="donation.php" alt="desciption"> Donation</a></li>
	<li><a href="edu.php" alt="desciption">Providing education</a></li>
	<li><a href="enroll.php" alt="desciption">Enrolling in NGO</a></li>
                
<li><a href="contact us.php" alt="desciption">Contact us</a></li>


	</ul>
</div>

<div id="nav" class="layout">

 <div id="lc" class="cols">
	 
	        <div id="lc1" class="lc_cls"> <br>
 <img src="child.jpg" height="200px" width="300px"><h4>HeLP Childrens By raising Funds </h4>

<b color="red">Children Care is to help poor childrens by providing them education,nutrion food, proper clothes,health checkups.</b>

<p>NGOs wanting to change the world without understanding it, and that the imperial relationship
 continues today with the rise of NGOs</p>
&nbsp &nbsp&nbsp&nbsp&nbsp<br>&nbsp&nbsp &nbsp &nbsp&nbsp&nbsp&nbsp&nbsp &nbsp&nbsp&nbsp&nbsp
<a href="enroll.php" alt="desciption"> 
Get Enrolled </a>

                 
    </div>
	 
	<div id="lc2" class=''lc_cls">
We help poor children by providing them education,nutrion food, proper clothes,health checkups etc.tothem...
        
<p>How do we do it?We work with the most disadvantaged local communities, sensitising and educating them about the rights of childrento help them understand 
that children are meant to be at school and not work.
We form Children Groups through which we bring together vulnerable children in a community. 
&nbsp &nbsp&nbsp 	           
<a href="donation.php" alt="desciption">Donation </a>

         </div>
   

 </div>           

 <div id="rc" class="cols">
 
      
        <img src="download.jpg" height="200px" width="400px">
 <h4>Change the life of Street Children </h4> 
<h4>WE offer hope you can Help</h4>
<p> These children then collectively work our solutions to help themselves and each other and ensure child rights in their 
 area are upheld. We work very closely with these Children Groups and train them to identify and prevent cases 
 of child marriage, child trafficking, child abuse and child labour.We map out-of-school children, street 
 children and those who are involved in child labour and facilitate theirmovement into schools by the means of enrolment drives.
<br>
</div>

<div id="footer" class="layout">
<a href="contact us.php" alt="description"><h1>Contact us</h1></a>
</div>

</div>
</body> 
</html>
