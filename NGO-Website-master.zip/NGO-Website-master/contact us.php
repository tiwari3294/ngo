
<html>
<head>
<title>NGO website</title>
<link type ="text/css" rel="stylesheet" href="mystyle.css">
</head>
<body>


<div id="header" class="layout">


  	
	<center><h1>Children Care</h1></center>
</div>
<div id="menu" class="layout">
		<ul>
<li><a href="home.php" alt="desciption">Home</a></li>
	<li><a href="donation.php" alt="desciption"> Donation</a></li>
	<li><a href="edu.php" alt="desciption">Providing education</a></li>
	<li><a href="enroll.php" alt="desciption">Enrolling in NGO</a></li>
                
<li><a href="contact us.php" alt="desciption">Contact us</a></li>


	</ul>
</div>

<div id="nav" class="layout">

<center><img src="contact.jpg" height="100px" width="1300px"></center>
 <center><h1>If You Know ANy Place where  Children are not in good  condition.</h1> 
       <h2> Please Contact us on this address..
<br>
Near Abc 123,
XYZ Building,
NEW DElhi,
011-234532,
9480380388
 </h2><h3>Share your views
</h3>
<form action="contct_db.php" method="POST">
<table>
<tr>
<td><h3><b> FEEDBACK :</b></h3>
<td><TEXTAREA name="comment" rows="3" cols="44" required></TEXTAREA></TD>

</tr>
<tr>

<td>
	<br>
<input type="submit" name="SHARE" value="FEEDBACK">
</td>
</tr></table></form>
</center>
        </div>
<div id="footer" class="layout">
<a href="About us.html" alt="description">About us</a>
</div>
